'use strict';
(() => {
 const $ = id => document.getElementById(id);
 const KEY = 'mi-iptv-v1-state';
 const PAGE = 50;
 const state = {playlists:[], channels:[]};
 let explorePage=1,savedPage=1,decisionFilter='all', savedFilter='keep', activeList=[],playerIndex=0,playerChannelId=null,toastTimer=0,saveTimer=0,db=null;
 const countryNames={MX:'México',ES:'España',AR:'Argentina',CL:'Chile',CO:'Colombia',PE:'Perú',EC:'Ecuador',CR:'Costa Rica',UY:'Uruguay',US:'Estados Unidos',PY:'Paraguay',BO:'Bolivia',VE:'Venezuela',DO:'República Dominicana',GT:'Guatemala',SV:'El Salvador',HN:'Honduras',NI:'Nicaragua',PA:'Panamá',CU:'Cuba',PR:'Puerto Rico',BR:'Brasil',DE:'Alemania',FR:'Francia',CA:'Canadá',GB:'Reino Unido',PT:'Portugal',IT:'Italia',JP:'Japón',NL:'Países Bajos'};
 const countryAlias={};Object.entries(countryNames).forEach(([code,name])=>{countryAlias[name.toLowerCase()]=name;countryAlias[code.toLowerCase()]=name});
 const nativeCategories={general:'Televisión general',news:'Noticias',sports:'Deportes',movies:'Películas',series:'Series',documentary:'Documentales',culture:'Cultura',education:'Educación',kids:'Infantiles',music:'Música',entertainment:'Entretenimiento',animation:'Animación',business:'Negocios',cooking:'Cocina',family:'Familia',legislative:'Legislativo',lifestyle:'Estilo de vida',outdoor:'Aire libre',relax:'Relajación',religious:'Religión',science:'Ciencia',shop:'Compras',travel:'Viajes',weather:'Clima',auto:'Automovilismo',classic:'Clásicos',comedy:'Comedia',gaming:'Videojuegos',history:'Historia',hobby:'Aficiones'};
 const icons={'Televisión general':'📺','Noticias':'📰','Deportes':'⚽','Películas':'🎬','Series':'🎞','Documentales':'🌿','Cultura':'🏛','Educación':'🎓','Infantiles':'🧸','Música':'🎵','Entretenimiento':'🎭','Sin categoría':'📡'};
 const esc = s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
 const norm = s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const safeUrl = s=>{try{const u=new URL(String(s).trim());return ['http:','https:'].includes(u.protocol)?u.href:''}catch{return ''}};
 const streamUrl = s=>{try{const u=new URL(String(s).trim());return ['http:','https:','rtsp:','rtmp:','udp:'].includes(u.protocol)?u.href:''}catch{return ''}};
 const initialCategories={'CanalOnce.mx':'Cultura','Lasestrellas.tv':'Entretenimiento','ADNNoticias.mx':'Noticias','TeleFormula.mx':'Noticias','Canal6Multimedios.mx':'Televisión general','QuieroTV.mx':'Televisión general','MexicoTravelTV.mx':'Viajes','EstrellaTV.mx':'Entretenimiento','Tele10Nayarit.mx':'Televisión general','noticiasnrt.com':'Televisión general','La1.es':'Televisión general','La2.es':'Cultura','24h.es':'Noticias','tdp.es':'Deportes','clan.es':'Infantiles','Telemadrid.es':'Televisión general','LaOtra.es':'Televisión general','CanalSurAndalucia.es':'Televisión general','Divinity.es':'Series','Energy.es':'Series','BeMad.es':'Entretenimiento','Aunar.ar':'Cultura','CineAr.ar':'Películas','TECTV.ar':'Educación','DeporTV.ar':'Deportes','Canal26.ar':'Noticias','MasPerfil.ar':'Noticias','Telemax.ar':'Televisión general','NETTV.ar':'Televisión general','TVUniversidad.ar':'Educación','ElTrece.ar':'Televisión general','AmericaTV.ar':'Televisión general','UCVTV.cl':'Televisión general','24Horas.cl':'Noticias','Canal13.cl':'Televisión general','UChileTV.cl':'Cultura','T13.cl':'Noticias','13C.cl':'Cultura','13Kids.cl':'Infantiles','13E.cl':'Entretenimiento','TVN3.cl':'Televisión general','mega.cl':'Televisión general','biobiochile.cl':'Noticias'};
 const textCountry = value => {const x=String(value||'').trim();if(!x)return ''; const first=x.split(/[;,]/)[0].trim();return countryAlias[first.toLowerCase()]||countryNames[first.toUpperCase()]||(/^[A-Z]{2}$/.test(first)?first:first)};
 const catName = raw => {let r=String(raw||'').trim();return nativeCategories[r.toLowerCase()]||r||'Sin categoría'};
 const hash = s => {let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(36)};
 const a = s => {const result={};for(const m of String(s).matchAll(/([\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))/g))result[m[1].toLowerCase()]=m[2]??m[3]??m[4]??'';return result};
 function parseM3U(text,playlistId){
   const lines=String(text).replace(/^\uFEFF/,'').split(/\r?\n/), channels=[];
   let meta=null;
   for(const untrimmed of lines){const line=untrimmed.trim();if(!line)continue;
     if(/^#EXTINF\s*:/i.test(line)){
       const comma=line.indexOf(',');const attrs=a(comma>=0?line.slice(0,comma):line);
       const name=(comma>=0?line.slice(comma+1).trim():'')||attrs['tvg-name']||'Canal sin nombre';
       const group=attrs['group-title']||'';
       let country=textCountry(attrs['tvg-country']||'');
       const possibleCountry=textCountry(group);
       let category=group;
       if(!country && possibleCountry && (countryAlias[group.toLowerCase()]||countryNames[group.toUpperCase()])){country=possibleCountry;category='';}
       if(!country && attrs['tvg-id']){const t=String(attrs['tvg-id']).match(/\.([a-z]{2})(?:@[^.]*)?$/i);if(t)country=textCountry(t[1])}
       meta={name, country:country||'Sin país', category:catName(category),logo:safeUrl(attrs['tvg-logo']),tvgId:attrs['tvg-id']||'',language:attrs['tvg-language']||'',group,rawExtinf:line};
       continue;
     }
     if(line.startsWith('#'))continue;
     const url=streamUrl(line);
     if(meta && url){channels.push({...meta,url,playlistId,id:playlistId+'-'+channels.length.toString(36),decision:'pending',favorite:false});meta=null;}
   }
   return channels;
 }
 async function getDB(){return new Promise((resolve,reject)=>{if(!('indexedDB' in window)){resolve(null);return;}const req=indexedDB.open('mi-iptv-persist',1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('kv'))req.result.createObjectStore('kv')};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
 async function readPersist(){try{db=await getDB();if(db){return await new Promise((resolve,reject)=>{const tx=db.transaction('kv','readonly');const req=tx.objectStore('kv').get(KEY);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}}catch(e){console.warn('Almacenamiento IndexedDB no disponible',e)}try{return JSON.parse(localStorage.getItem(KEY))}catch{return null}}
 async function writePersist(snapshot){if(db){try{await new Promise((resolve,reject)=>{const t=db.transaction('kv','readwrite');t.objectStore('kv').put(snapshot,KEY);t.oncomplete=resolve;t.onerror=()=>reject(t.error)});return}catch(e){console.warn('No se pudo escribir en IndexedDB',e)}}try{localStorage.setItem(KEY,JSON.stringify(snapshot))}catch(e){if(location.protocol!=='about:'&&location.protocol!=='file:')toast('Sin espacio para guardar los datos. Descarga una copia de seguridad.')}}
 function save(){clearTimeout(saveTimer);saveTimer=setTimeout(()=>writePersist({version:1,playlists:state.playlists,channels:state.channels}),350)}
 function toast(message){const el=$('toast');el.textContent=message;el.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.add('hidden'),4200)}
 function counts(){return {total:state.channels.length,keep:state.channels.filter(c=>c.decision==='keep').length,remove:state.channels.filter(c=>c.decision==='remove').length,pending:state.channels.filter(c=>c.decision==='pending').length,favorite:state.channels.filter(c=>c.favorite).length}}
 function statsHtml(entries){return entries.map(([n,label])=>`<div class="stat"><strong>${n.toLocaleString('es-MX')}</strong><span>${esc(label)}</span></div>`).join('')}
 function countryOptions(){return [...new Set(state.channels.map(c=>c.country))].sort((x,y)=>x.localeCompare(y,'es'))}
 function categoryOptions(){return [...new Set(state.channels.map(c=>c.category))].sort((x,y)=>x.localeCompare(y,'es'))}
 function optOptions(el,items,first){const selected=el.value;el.innerHTML=`<option value="">${esc(first)}</option>`+items.map(item=>`<option value="${esc(item.id??item)}">${esc(item.name??item)}</option>`).join('');if([...el.options].some(o=>o.value===selected))el.value=selected}
 function renderHome(){const co=counts();$('home-stats').innerHTML=statsHtml([[co.total,'Canales registrados'],[co.keep,'Conservar'],[co.favorite,'Favoritos']]);const groups={};for(const c of state.channels)groups[c.category]=(groups[c.category]||0)+1;
   $('home-categories').innerHTML=(Object.entries(groups).sort((x,y)=>y[1]-x[1]).slice(0,12).map(([cat,n])=>`<button class="category-tile" data-category="${esc(cat)}"><span class="glyph">${icons[cat]||'📺'}</span><span><b>${esc(cat)}</b><small>${n.toLocaleString('es-MX')} canales</small></span></button>`).join(''))||'<div class="empty">Sin categorías todavía.</div>';
   $('home-playlists').innerHTML=state.playlists.map(p=>`<div class="playlist-row"><div><h4>${esc(p.name)}</h4><p>${p.count.toLocaleString('es-MX')} canales</p></div><button class="smallbtn" data-openlist="${esc(p.id)}">Ver →</button></div>`).join('')||'<div class="empty">Importa tu primera lista para empezar.</div>';
 }
 function matchesExplore(){const search=norm($('searchInput').value.trim()),list=$('listFilter').value,country=$('countryFilter').value,cat=$('categoryFilter').value;
   return state.channels.filter(c=>(!list||c.playlistId===list)&&(!country||c.country===country)&&(!cat||c.category===cat)&&(!search||norm(c.name+' '+c.country+' '+c.category).includes(search))&&(decisionFilter==='all'||(decisionFilter==='favorite'?c.favorite:c.decision===decisionFilter)));
 }
 function cardHtml(c){const p=state.playlists.find(p=>p.id===c.playlistId);let img=c.logo?`<img class="channel-logo" loading="lazy" alt="" src="${esc(c.logo)}" onerror="this.outerHTML='<span class=&quot;channel-logo fake&quot;>TV</span>'">`:'<span class="channel-logo fake">TV</span>';
   return `<article class="channel-card" data-cid="${esc(c.id)}"><div class="channel-first">${img}<div style="min-width:0;flex:1"><div class="channel-name">${esc(c.name)}</div><div class="channel-info">${esc(c.country)} · ${esc(c.category)}${c.categoryOrigin?' (sugerida)':''}${p?' · '+esc(p.name):''}</div></div><button class="playbtn" data-play="${esc(c.id)}" aria-label="Reproducir ${esc(c.name)}">▶</button></div><div class="channel-actions"><button data-decision="keep" class="choicebtn keep ${c.decision==='keep'?'active':''}" aria-pressed="${c.decision==='keep'}">✓ Conservar</button><button data-decision="remove" class="choicebtn remove ${c.decision==='remove'?'active':''}" aria-pressed="${c.decision==='remove'}">× Quitar</button><button data-favorite class="choicebtn favorite ${c.favorite?'active':''}" aria-pressed="${c.favorite}" aria-label="Favorito">${c.favorite?'♥':'♡'}</button></div></article>`;
 }
 function pager(root,total,page,kind){const pageCount=Math.max(1,Math.ceil(total/PAGE));root.innerHTML=total>PAGE?`<button data-page="${kind}" data-value="${page-1}" ${page<=1?'disabled':''}>← Anterior</button><span>Página ${page.toLocaleString('es-MX')} de ${pageCount.toLocaleString('es-MX')}</span><button data-page="${kind}" data-value="${page+1}" ${page>=pageCount?'disabled':''}>Siguiente →</button>`:''}
 function renderExplore(){optOptions($('listFilter'),state.playlists,'Todas las listas');optOptions($('countryFilter'),countryOptions(),'Todos los países');optOptions($('categoryFilter'),categoryOptions(),'Todas las categorías');
   const filtered=matchesExplore();explorePage=Math.min(explorePage,Math.max(1,Math.ceil(filtered.length/PAGE)));$('resultCount').textContent=`${filtered.length.toLocaleString('es-MX')} de ${state.channels.length.toLocaleString('es-MX')} canales · ${PAGE} por página`;
   $('channelsList').innerHTML=filtered.slice((explorePage-1)*PAGE,explorePage*PAGE).map(cardHtml).join('')||'<div class="empty"><strong>No hay canales con estos filtros</strong>Puedes cambiar los filtros o agregar una lista M3U.</div>';pager($('pagination'),filtered.length,explorePage,'explore');
   document.querySelectorAll('[data-choice]').forEach(b=>b.classList.toggle('selected',b.dataset.choice===decisionFilter));
 }
 function savedResults(){return state.channels.filter(c=>savedFilter==='favorite'?c.favorite:c.decision===savedFilter)}
 function renderSaved(){const co=counts();$('saved-stats').innerHTML=statsHtml([[co.keep,'Conservar'],[co.remove,'Quitar'],[co.pending,'Pendientes']]);document.querySelectorAll('[data-saved]').forEach(b=>b.classList.toggle('selected',b.dataset.saved===savedFilter));const results=savedResults();savedPage=Math.min(savedPage,Math.max(1,Math.ceil(results.length/PAGE)));$('savedDescription').textContent=`${results.length.toLocaleString('es-MX')} canales en «${savedFilter==='keep'?'Conservar':savedFilter==='remove'?'Quitar':savedFilter==='favorite'?'Favoritos':'Pendientes'}».`;$('savedChannels').innerHTML=results.slice((savedPage-1)*PAGE,savedPage*PAGE).map(cardHtml).join('')||'<div class="empty">Todavía no hay canales en esta selección.</div>';pager($('savedPagination'),results.length,savedPage,'saved')}
 function renderPlaylists(){$('playlistCount').textContent=state.playlists.length+' listas';$('savedPlaylists').innerHTML=state.playlists.map(p=>`<div class="playlist-row"><div><h4>${esc(p.name)}</h4><p>${p.count.toLocaleString('es-MX')} canales · ${esc(p.source==='builtin'?'Incluida de ejemplo':p.source==='file'?'Archivo local':'URL')}</p></div><div class="playlist-row-actions"><button class="smallbtn" data-openlist="${esc(p.id)}" aria-label="Explorar ${esc(p.name)}">Ver</button><button class="smallbtn red" data-deletelist="${esc(p.id)}" aria-label="Eliminar ${esc(p.name)}">×</button></div></div>`).join('')||'<div class="empty">No hay listas importadas.</div>'}
 function renderAll(){renderHome();renderExplore();renderPlaylists();renderSaved()}
 function go(screen){if(!document.getElementById('screen-'+screen))return;document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active',s.id==='screen-'+screen));document.querySelectorAll('[data-nav]').forEach(b=>b.classList.toggle('active',b.dataset.nav===screen));if(screen==='explore')renderExplore();if(screen==='saved')renderSaved();if(screen==='playlists')renderPlaylists();if(screen==='home')renderHome();window.scrollTo({top:0,behavior:'instant'})}
 function updateChannel(id,fn){const c=state.channels.find(x=>x.id===id);if(!c)return;fn(c);save();renderHome();renderExplore();renderSaved();updatePlayerButtons()}
 function addList(name,text,source,remote){const parsedName=String(name||'Lista importada').trim().slice(0,100);const id='p-'+hash(parsedName+'|'+text.slice(0,300)+'|'+text.length), channels=parseM3U(text,id);
   if(source==='builtin')for(const c of channels){if(initialCategories[c.tvgId]){c.category=initialCategories[c.tvgId];c.categoryOrigin='clasificación sugerida';}}
   if(!channels.length)throw new Error('No se encontraron canales. Selecciona un archivo M3U que contenga líneas #EXTINF seguidas de direcciones HTTP(S).');
   if(state.playlists.some(p=>p.id===id))throw new Error('Esta lista ya está importada. Puedes verla en Mis listas.');
   state.playlists.push({id,name:parsedName,count:channels.length,source,url:remote||'',createdAt:new Date().toISOString()});state.channels.push(...channels);save();renderAll();toast(`${channels.length.toLocaleString('es-MX')} canales importados`);return channels.length;
 }
 function updatePlayerButtons(){const c=state.channels.find(x=>x.id===playerChannelId);if(!c)return;$('playerFavorite').textContent=(c.favorite?'♥ Quitar favorito':'♡ Favorito');$('playerKeep').textContent=c.decision==='keep'?'✓ Conservado':'✓ Conservar';$('playerRemove').textContent=c.decision==='remove'?'× Quitado':'× Quitar'}
 function showPlayer(id){const c=state.channels.find(x=>x.id===id);if(!c)return;playerChannelId=id;
   let pool=matchesExplore();if(!pool.some(x=>x.id===id))pool=state.channels.filter(x=>x.playlistId===c.playlistId);activeList=pool.map(x=>x.id);playerIndex=activeList.indexOf(id);
   $('playerTitle').textContent=c.name;$('playerSubtitle').textContent=c.country+' · '+c.category;$('playerBackdrop').classList.remove('hidden');$('playerModal').classList.remove('hidden');$('playStatus').classList.add('hidden');updatePlayerButtons();
   const v=$('video');v.pause();v.removeAttribute('src');v.load();if(!safeUrl(c.url)){$('playStatus').textContent='Este tipo de señal no se reproduce en Safari. Puedes conservarlo y exportarlo para probarlo en VLC.';$('playStatus').classList.remove('hidden');return;}v.src=c.url;v.load();const p=v.play();if(p?.catch)p.catch(()=>{$('playStatus').textContent='Pulsa ▶ para iniciar. Si el canal no abre, puede estar bloqueado o no ser compatible con Safari.';$('playStatus').classList.remove('hidden')});
 }
 function closePlayer(){const v=$('video');v.pause();v.removeAttribute('src');v.load();$('playerBackdrop').classList.add('hidden');$('playerModal').classList.add('hidden');playerChannelId=null}
 function jumpPlayer(dir){if(!activeList.length)return;const i=(playerIndex+dir+activeList.length)%activeList.length;showPlayer(activeList[i]);playerIndex=i}
 function download(name,content,type){const blob=new Blob([content],{type:type||'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),2000)}
 function exportM3U(which){const items=state.channels.filter(c=>which==='favorite'?c.favorite:c.decision==='keep');if(!items.length){toast('No hay canales seleccionados para exportar.');return}
   const rows=['#EXTM3U','# Exportado desde Mi IPTV. La reproducción de las señales no está garantizada.'];for(const c of items){let metadata=`tvg-id="${String(c.tvgId).replace(/"/g,'')}" tvg-logo="${c.logo.replace(/"/g,'')}" group-title="${c.group.replace(/"/g,'')}"`;rows.push(`#EXTINF:-1 ${metadata},${c.name.replace(/[\r\n]/g,' ')}`,c.url)}download(`Mi_IPTV_${which==='favorite'?'Favoritos':'Conservados'}_${new Date().toISOString().slice(0,10)}.m3u`,rows.join('\n')+'\n','application/x-mpegURL;charset=utf-8');toast(`${items.length.toLocaleString('es-MX')} canales exportados`)}
 function setupEvents(){document.body.addEventListener('click',event=>{
   const b=event.target.closest('button');if(!b)return;
   if(b.dataset.nav){go(b.dataset.nav);return}if(b.dataset.go){go(b.dataset.go);return}if(b.id==='settingsTop'){go('settings');return}
   if(b.dataset.category){go('explore');$('categoryFilter').value=b.dataset.category;explorePage=1;renderExplore();return}
   if(b.dataset.openlist){go('explore');$('listFilter').value=b.dataset.openlist;explorePage=1;renderExplore();return}
   if(b.dataset.choice){decisionFilter=b.dataset.choice;explorePage=1;renderExplore();return}
   if(b.dataset.saved){savedFilter=b.dataset.saved;savedPage=1;renderSaved();return}
   if(b.dataset.page){if(b.dataset.page==='saved'){savedPage=Number(b.dataset.value);renderSaved()}else{explorePage=Number(b.dataset.value);renderExplore()}window.scrollTo({top:120,behavior:'smooth'});return}
   if(b.dataset.play){showPlayer(b.dataset.play);return}
   const card=b.closest('[data-cid]');if(card && b.dataset.decision){const type=b.dataset.decision;updateChannel(card.dataset.cid,c=>{c.decision=c.decision===type?'pending':type});return}
   if(card && b.hasAttribute('data-favorite')){updateChannel(card.dataset.cid,c=>{c.favorite=!c.favorite});return}
   if(b.dataset.deletelist){const p=state.playlists.find(x=>x.id===b.dataset.deletelist);if(p&&confirm(`¿Eliminar «${p.name}» y todos sus canales de Mi IPTV?`)){state.playlists=state.playlists.filter(x=>x.id!==p.id);state.channels=state.channels.filter(x=>x.playlistId!==p.id);save();renderAll();toast('Lista eliminada')}return}
 });
 ['searchInput','listFilter','countryFilter','categoryFilter'].forEach(id=>$(id).addEventListener(id==='searchInput'?'input':'change',()=>{explorePage=1;renderExplore()}));
 $('clearSearch').onclick=()=>{$('searchInput').value='';explorePage=1;renderExplore()};$('resetExploreFilters').onclick=()=>{$('searchInput').value='';$('listFilter').value='';$('countryFilter').value='';$('categoryFilter').value='';decisionFilter='all';explorePage=1;renderExplore()};
 $('playlistFile').addEventListener('change',e=>{$('chosenFile').textContent=e.target.files?.[0]?.name||'Aún no has elegido un archivo.'});
 document.querySelectorAll('.addtab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.addtab').forEach(x=>x.classList.toggle('selected',x===b));$('formFile').classList.toggle('hidden',b.dataset.type!=='file');$('formUrl').classList.toggle('hidden',b.dataset.type!=='url')}));
 $('formFile').addEventListener('submit',async e=>{e.preventDefault();const file=$('playlistFile').files?.[0];if(!file){toast('Primero selecciona el archivo M3U.');return}try{let data=await file.text();addList($('fileName').value||file.name,data,'file');$('formFile').reset();$('chosenFile').textContent='Aún no has elegido un archivo.';go('explore')}catch(err){toast(err.message)}});
 async function fetchM3U(url){const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),25000);try{const response=await fetch(url,{signal:ctl.signal,cache:'no-store'});if(!response.ok)throw new Error(`El servidor respondió ${response.status}.`);const text=await response.text();if(!/^\s*#EXTM3U/m.test(text)||!/#EXTINF\s*:/i.test(text))throw new Error('La fuente no devolvió una lista M3U válida.');return text}finally{clearTimeout(timer)}}
 const IPTV_ORG_FEEDS=[
   {name:'IPTV-org español', label:'Español', sources:[
     'https://iptv-org.github.io/iptv/languages/spa.m3u',
     'https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/languages/spa.m3u',
     'https://cdn.jsdelivr.net/gh/iptv-org/iptv@gh-pages/languages/spa.m3u'
   ]},
   {name:'IPTV-org Latinoamérica', label:'Latinoamérica', sources:[
     'https://iptv-org.github.io/iptv/regions/latam.m3u',
     'https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/regions/latam.m3u',
     'https://cdn.jsdelivr.net/gh/iptv-org/iptv@gh-pages/regions/latam.m3u'
   ]}
 ];
 // La lista de idioma español se conserva tal como la clasifica IPTV-org.
 // La lista LATAM es un criterio regional adicional: puede incluir señales
 // sin etiqueta de idioma, por decisión expresa del usuario.
 // No sustituimos listas existentes ni alteramos sus favoritos o decisiones.
 function addUniqueCatalog(feed, text, remote){
   if(state.playlists.some(p=>p.name===feed.name))return {status:'existing',added:0,skipped:0};
   const id='p-'+hash(feed.name+'|'+text.slice(0,300)+'|'+text.length);
   const candidates=parseM3U(text,id);
   if(!candidates.length)throw new Error('La fuente no contiene canales reproducibles en formato M3U.');
   const seen=new Set(state.channels.map(c=>c.url.trim()));
   const channels=[];
   for(const c of candidates){
     const key=c.url.trim();
     if(seen.has(key))continue;
     seen.add(key);
     c.sourceScope=feed.label;
     channels.push(c);
   }
   const skipped=candidates.length-channels.length;
   state.playlists.push({id,name:feed.name,count:channels.length,source:'url',url:remote,createdAt:new Date().toISOString()});
   state.channels.push(...channels);
   save();renderAll();
   return {status:'added',added:channels.length,skipped};
 }
 async function importSpanishAndLatam(button){
   button.disabled=true;
   const previous=button.textContent;
   const reports=[],errors=[];
   try{
     for(const feed of IPTV_ORG_FEEDS){
       if(state.playlists.some(p=>p.name===feed.name)){
         reports.push(feed.label+': ya estaba importada');
         continue;
       }
       let imported=false,lastError='';
       for(let i=0;i<feed.sources.length;i++){
         button.textContent=`Descargando ${feed.label} (${i+1}/${feed.sources.length})…`;
         try{
           const text=await fetchM3U(feed.sources[i]);
           const r=addUniqueCatalog(feed,text,feed.sources[i]);
           reports.push(`${feed.label}: ${r.added.toLocaleString('es-MX')} nuevos; ${r.skipped.toLocaleString('es-MX')} duplicados omitidos`);
           imported=true;
           break;
         }catch(err){lastError=err.message||String(err)}
       }
       if(!imported)errors.push(`${feed.label}: ${lastError}`);
     }
     if(reports.length){
       go('explore');
       // Mostrar todas las listas, para poder explorar y filtrar libremente.
       $('listFilter').value='';
       explorePage=1;
       renderExplore();
       toast('Catálogos procesados. Revisa los canales en Explorar.');
     }
     if(errors.length){
       alert('Una o más fuentes no pudieron cargarse. Tus listas, favoritos y selecciones anteriores siguen intactos.\n\n'+errors.join('\n')+'\n\nSi Safari bloquea la conexión, puedes descargar spa.m3u y latam.m3u desde GitHub e importarlos desde «Mis listas → Desde Archivos».');
     }else if(reports.length){
       alert('Actualización terminada.\n\n'+reports.join('\n')+'\n\nPuedes revisar individualmente los canales en Explorar. La reproducción no está verificada.');
     }
   }finally{
     button.disabled=false;
     button.textContent=previous;
   }
 }
 async function importFromUrl(name,url,button){button.disabled=true;const prev=button.textContent;button.textContent='Descargando lista…';try{const txt=await fetchM3U(url);addList(name,txt,'url',url);go('explore');return true}catch(err){alert('No fue posible descargar la lista: '+err.message+'\n\nEs posible que Safari bloquee la conexión por restricciones de origen (CORS), que el servidor no responda o que no haya Internet. Como alternativa, descarga el archivo M3U y utiliza «Desde Archivos».');return false}finally{button.disabled=false;button.textContent=prev}}
 $('formUrl').addEventListener('submit',async e=>{e.preventDefault();const url=safeUrl($('playlistUrl').value);if(!url){toast('Introduce una dirección HTTP(S) válida.');return}const ok=await importFromUrl($('urlName').value||url.split('/').pop(),url,$('formUrl').querySelector('[type=submit]'));if(ok)$('formUrl').reset()});
 $('quickSpanish').onclick=()=>importSpanishAndLatam($('quickSpanish'));
 $('playerBackdrop').onclick=closePlayer;$('closePlayer').onclick=closePlayer;$('previousChannel').onclick=()=>jumpPlayer(-1);$('nextChannel').onclick=()=>jumpPlayer(1);
 $('video').addEventListener('error',()=>{$('playStatus').textContent='La señal no se puede reproducir. Comprueba si está disponible o tiene restricciones. También puedes probar su URL en VLC.';$('playStatus').classList.remove('hidden')});$('video').addEventListener('playing',()=>$('playStatus').classList.add('hidden'));
 $('playerFavorite').onclick=()=>{if(playerChannelId)updateChannel(playerChannelId,c=>{c.favorite=!c.favorite})};$('playerKeep').onclick=()=>{if(playerChannelId)updateChannel(playerChannelId,c=>{c.decision='keep'})};$('playerRemove').onclick=()=>{if(playerChannelId)updateChannel(playerChannelId,c=>{c.decision='remove'})};
 $('copyStream').onclick=async()=>{const c=state.channels.find(x=>x.id===playerChannelId);if(!c)return;try{await navigator.clipboard.writeText(c.url);toast('Dirección copiada')}catch{prompt('Copia la dirección:',c.url)}};
 $('exportKept').onclick=()=>exportM3U('keep');$('exportFavorites').onclick=()=>exportM3U('favorite');
 $('backupBtn').onclick=()=>download('Mi_IPTV_respaldo_'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify({version:1,playlists:state.playlists,channels:state.channels},null,2),'application/json');
 $('restoreFile').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;try{const v=JSON.parse(await file.text());if(!Array.isArray(v.playlists)||!Array.isArray(v.channels))throw new Error('Copia no válida');if(!confirm('¿Reemplazar tus listas y decisiones actuales con esta copia?'))return;state.playlists=v.playlists;state.channels=v.channels;save();renderAll();toast('Copia restaurada')}catch(err){toast('No se pudo restaurar: '+err.message)}finally{e.target.value=''}});
 $('deleteAll').onclick=()=>{if(confirm('¿Eliminar todas las listas, selecciones y favoritos? Esta acción no se puede deshacer.')){state.playlists=[];state.channels=[];save();renderAll();toast('Datos eliminados')}};
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&playerChannelId)closePlayer()});
 }
 async function boot(){setupEvents();const loaded=await readPersist();if(loaded&&Array.isArray(loaded.playlists)&&Array.isArray(loaded.channels)){state.playlists=loaded.playlists;state.channels=loaded.channels;}else{try{addList('43 canales originales',window.IPTV_DEMO_M3U,'builtin')}catch(e){console.warn('No se pudo preparar la lista inicial:',e)}}renderAll();go('home');$('installStatus').textContent=location.protocol==='https:'?'Se puede añadir a la pantalla de inicio desde Safari.':'Para instalar como app, publica la carpeta en un servicio HTTPS. Abrir el HTML desde Archivos o iZip puede limitar sus funciones.';if('serviceWorker' in navigator && (location.protocol==='https:'||location.hostname==='localhost'))navigator.serviceWorker.register('./sw.js').catch(e=>console.warn(e));}
 boot();
})();
